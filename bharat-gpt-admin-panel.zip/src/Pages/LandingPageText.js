import React from "react";

const VideoGallery = () => {
  return <div>
    
  </div>;
};

export default VideoGallery;
